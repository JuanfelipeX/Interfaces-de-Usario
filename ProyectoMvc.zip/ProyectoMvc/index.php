<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="Views/Bienvenida.php">Bienvenida</a>
    <a href="Controller/UsuariosController.php">Usuarios</a>
    <a href="Views/VistaNuevoUsuario.php">Nuevo Usuario</a>
    <a href="Views/VistaEliminaUsuario.php">Eliminar Usuario</a>
    <a href="Views/VistaActualizarUsuario.php">Actualizar Usuario</a>
</body>
</html>
