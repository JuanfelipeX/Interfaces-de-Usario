
 
</div>

<!-- JQuery-->
<script src="../js/jquery-3.6.0.min.js"></script>
<!-- Popper JS -->
<script src="https://unpkg.com/@popperjs/core@2"></script>
<!-- Bootstrap JS -->
<script src="../js/bootstrap.min.js"></script>
<!-- Other JS -->
<script defer src="../js/solid.js"></script>
<script defer src="../js/fontawesome.js"></script>
<!-- Custom JS -->
<script src="../js/custom.js"></script>

</body>

</html>