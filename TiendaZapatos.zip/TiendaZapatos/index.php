<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda de Zapatos</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>Bienvenido a Nuestra Zapateria</h1>
    <h3>Elige la opcion que necesites</h3>
    
    <ul>
        <li>
            <a href="Views/VistaComprarProducto.php">Registrar producto</a>
        </li>
        
        <li>
             <a href="Views/VistaEliminarProducto.php">Eliminar producto</a>
        </li>

        <li>
            <a href="Views/VistaModificarProducto.php">Modificar producto</a>
        </li>

        <li>
            <a href="Views/VistaConsultarProducto.php">Consultar productos</a>
        </li>
    </ul>
</body>
</html>  